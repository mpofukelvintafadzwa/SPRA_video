import numpy as np
import cv2
from matplotlib import pyplot as plt

def fft_image(image_path):
    # Read the image in grayscale
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Perform the 2D FFT on the image
    f = np.fft.fft2(img)
    # Shift the zero-frequency component to the center of the spectrum
    fshift = np.fft.fftshift(f)
    # Compute the magnitude spectrum
    magnitude_spectrum = 20 * np.log(np.abs(fshift))

    # Display the original image and the magnitude spectrum
    plt.subplot(121), plt.imshow(img, cmap='gray')
    plt.title('Input Image'), plt.xticks([]), plt.yticks([])
    plt.subplot(122), plt.imshow(magnitude_spectrum, cmap='gray')
    plt.title('Magnitude Spectrum'), plt.xticks([]), plt.yticks([])
    plt.show()

# Example usage:
image_path = 'IMG_0750.JPG'
fft_image(image_path)
