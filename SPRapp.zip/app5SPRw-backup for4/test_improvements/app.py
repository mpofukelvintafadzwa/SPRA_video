from flask import Flask, render_template, request, send_file
import numpy as np
import io
import base64
import matplotlib.pyplot as plt
import math
import cmath
import pandas as pd

app = Flask(__name__)

# Constants
lightspeed = 299792458

def npBK7(lambda_val):
    term1 = 1 + 1.03961212 * lambda_val**2 / (lambda_val**2 - 0.00600069867)
    term2 = 0.231792344 * lambda_val**2 / (lambda_val**2 - 0.0200179144)
    term3 = 1.01046945 * lambda_val**2 / (lambda_val**2 - 103.560653)
    result = math.sqrt(term1 + term2 + term3)
    return result**2

def safe_sqrt(val):
    if val >= 0:
        return np.sqrt(val)
    else:
        return cmath.sqrt(val)

def nr_plasma(lambda_vals):
    lambda_val = lambda_vals * (10**9)
    A, B, C = 1.3353, 4.4048e3, -9.1925e7
    return (A + B / lambda_val**2 + C / lambda_val**4)**2

def nr_wholeblood(lambda_vals):
    lambda_val = lambda_vals * (10**9)
    A, B, C, D = 0.7960, 5.1819, 1.0772e4, -7.8301e5
    term1 = A * lambda_val**2 / (lambda_val**2 - C)
    term2 = B * lambda_val**2 / (lambda_val**2 - D)
    return (1 + term1 + term2)**2

def nr_serum(lambda_vals):
    lambda_val = lambda_vals * (10**9)
    A, B, C = 1.3350, 4.6513e3, -1.3069e8
    return (A + B / lambda_val**2 + C / lambda_val**4)**2

def drude_model(gamma, omega_p, omega):
    n = 1j
    return 1 - gamma**2 * omega / (omega_p**2 * (omega + gamma * n))

def compute_R(theta_deg, lambda_value, epsilon1, epsilon2, epsilon3, d):
    w = (2 * np.pi * lightspeed) / lambda_value
    k0 = w / lightspeed
    kx = k0 * np.sqrt(epsilon1) * np.sin(np.radians(theta_deg))
    kz1 = safe_sqrt(epsilon1 * k0**2 - kx**2)
    kz2 = safe_sqrt(epsilon2.real * k0**2 - kx**2)
    kz3 = safe_sqrt(epsilon3 * k0**2 - kx**2)
    part1 = np.exp(1j * 2 * kz2 * d)
    part2 = kz2 / epsilon2 - kz3 / epsilon3
    part3 = kz2 / epsilon2 + kz3 / epsilon3
    part4 = kz1 / epsilon1 - kz2 / epsilon2
    part5 = kz1 / epsilon1 + kz2 / epsilon2
    part7 = part4 / part5
    part6 = part2 / part3 if np.abs(part3) > 1e-10 else 0
    denominator = part1 * part6 * part7 + 1
    R = (part1 * part6 + part7) / denominator if np.abs(denominator) > 1e-10 else 0
    return R

@app.route('/', methods=['GET', 'POST'])
def index():
    plot_url = None
    spr_angle = None
    error = None

    if request.method == 'POST':
        try:
            # Wavelength
            lambda_value = request.form.get('lambda_value')
            if not lambda_value:
                error = "Wavelength (lambda) value is missing!"
                return render_template('index.html', error=error)
            lambda_value = float(lambda_value) * 1e-9  # Convert nm to m

            # Thickness
            thickness_nm = request.form.get('thickness')
            if not thickness_nm:
                error = "Metal layer thickness is missing!"
                return render_template('index.html', error=error)
            d = float(thickness_nm) * 1e-9  # Convert nm to m

            # Epsilon1
            epsilon1_type = request.form.get('epsilon1')
            if epsilon1_type == 'custom':
                epsilon1_custom = request.form.get('epsilon1_custom')
                if not epsilon1_custom:
                    error = "Custom Epsilon1 value is missing!"
                    return render_template('index.html', error=error)
                epsilon1 = float(epsilon1_custom)
            else:
                epsilon1 = npBK7(lambda_value * 1e6)

            # Epsilon2
            epsilon2_type = request.form.get('epsilon2')
            if epsilon2_type == 'custom':
                real_part = request.form.get('epsilon2_real')
                imag_part = request.form.get('epsilon2_imag')
                if not real_part or not imag_part:
                    error = "Custom Epsilon2 real/imaginary parts are missing!"
                    return render_template('index.html', error=error)
                epsilon2 = complex(float(real_part), float(imag_part))
            elif epsilon2_type == 'gold':
                epsilon2 = drude_model(lambda_value, 1.6826e-7, 8.9342e-6)
            elif epsilon2_type == 'silver':
                epsilon2 = drude_model(lambda_value, 1.4541e-7, 1.7614e-5)
            elif epsilon2_type == 'aluminium':
                epsilon2 = drude_model(lambda_value, 1.0657e-7, 2.4511e-5)
            elif epsilon2_type == 'copper':
                epsilon2 = drude_model(lambda_value, 1.3617e-7, 4.0852e-5)

            # Epsilon3
            epsilon3_type = request.form.get('epsilon3', 'nr_plasma')
            if epsilon3_type == 'custom':
                epsilon3_custom = request.form.get('epsilon3_custom')
                if not epsilon3_custom:
                    error = "Custom Epsilon3 value is missing!"
                    return render_template('index.html', error=error)
                epsilon3 = float(epsilon3_custom)
            elif epsilon3_type == 'nr_plasma':
                epsilon3 = nr_plasma(lambda_value)
            elif epsilon3_type == 'nr_wholeblood':
                epsilon3 = nr_wholeblood(lambda_value)
            elif epsilon3_type == 'nr_serum':
                epsilon3 = nr_serum(lambda_value)

            # Compute reflectance
            theta_range = np.linspace(0, 90, 500)
            R_values = [compute_R(theta, lambda_value, epsilon1, epsilon2, epsilon3, d) for theta in theta_range]

            # SPR angle
            min_idx = np.argmin(np.abs(R_values)**2)
            spr_angle = theta_range[min_idx]

            # Plot
            plt.figure(figsize=(8, 6))
            plt.plot(theta_range, np.abs(R_values)**2, label='|R|²', linewidth=2)
            plt.plot(spr_angle, np.abs(R_values[min_idx])**2, 'ro')
            plt.annotate(f'SPR: {spr_angle:.2f}°',
                         xy=(spr_angle, np.abs(R_values[min_idx])**2),
                         xytext=(spr_angle + 5, 0.5),
                         arrowprops=dict(arrowstyle='->', color='red'),
                         fontsize=12, color='red')
            plt.xlabel('Angle (degrees)')
            plt.ylabel('Intensity')
            #plt.title('Reflectance vs Angle')
            plt.grid(True)
            #plt.legend()
            img = io.BytesIO()
            plt.savefig(img, format='png')
            img.seek(0)
            plot_url = base64.b64encode(img.getvalue()).decode()
            plt.close()

            return render_template('result.html', plot_url=plot_url, spr_angle=spr_angle)

        except Exception as e:
            error = f"Unexpected error: {str(e)}"
            return render_template('index.html', error=error)

    return render_template('index.html', error=error)

@app.route('/download')
def download_excel():
    try:
        # These should ideally be saved during POST processing
        theta_range = np.linspace(0, 90, 500)
        lambda_value = 633e-9  # default test wavelength
        d = 50e-9  # default thickness
        epsilon1 = npBK7(lambda_value * 1e6)
        epsilon2 = drude_model(lambda_value, 1.6826e-7, 8.9342e-6)
        epsilon3 = nr_plasma(lambda_value)

        R_values = [compute_R(theta, lambda_value, epsilon1, epsilon2, epsilon3, d) for theta in theta_range]
        reflectance = np.abs(R_values) ** 2

        df = pd.DataFrame({
            'Angle (degrees)': theta_range,
            '|R|^2': reflectance
        })

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Reflectance')
        output.seek(0)

        return send_file(output, download_name="reflectance_data.xlsx", as_attachment=True)

    except Exception as e:
        return f"Error generating Excel file: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)
